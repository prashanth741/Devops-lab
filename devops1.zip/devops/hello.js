
console.log("Hello World from Node.js");


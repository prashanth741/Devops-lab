const fs = require('fs');
fs.writeFileSync("sample.txt", "This is a Node.js file");
console.log("File created successfully");